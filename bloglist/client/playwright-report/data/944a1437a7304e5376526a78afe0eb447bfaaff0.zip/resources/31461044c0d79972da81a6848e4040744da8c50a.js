import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3eb2504a"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/BlogForm.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=3eb2504a"; const useState = __vite__cjsImport3_react["useState"];
const BlogForm = ({ createBlog }) => {
  _s();
  const [blogTitle, setBlogTitle] = useState("");
  const [blogAuthor, setBlogAuthor] = useState("");
  const [blogUrl, setBlogUrl] = useState("");
  const createNewBlog = async (event) => {
    event.preventDefault();
    createBlog({
      title: blogTitle,
      author: blogAuthor,
      url: blogUrl
    });
    setBlogTitle("");
    setBlogAuthor("");
    setBlogUrl("");
  };
  return /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("form", { onSubmit: createNewBlog, children: [
    /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("label", { children: [
      "Title:",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: blogTitle,
          onChange: ({ target }) => setBlogTitle(target.value)
        },
        void 0,
        false,
        {
          fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 45,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 43,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 42,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("label", { children: [
      "Author:",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: blogAuthor,
          onChange: ({ target }) => setBlogAuthor(target.value)
        },
        void 0,
        false,
        {
          fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 55,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 53,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 52,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("label", { children: [
      "Url:",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: blogUrl,
          onChange: ({ target }) => setBlogUrl(target.value)
        },
        void 0,
        false,
        {
          fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 65,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 63,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 62,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "create" }, void 0, false, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 72,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/BlogForm.jsx",
    lineNumber: 41,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/BlogForm.jsx",
    lineNumber: 40,
    columnNumber: 5
  }, this);
};
_s(BlogForm, "5U/Z2vLYtJlOEzyiH183iHolmd8=");
_c = BlogForm;
export default BlogForm;
var _c;
$RefreshReg$(_c, "BlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/BlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/BlogForm.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJZOzs7Ozs7Ozs7Ozs7Ozs7OztBQXpCWixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsV0FBV0EsQ0FBQyxFQUFFQyxXQUFXLE1BQU07QUFBQUMsS0FBQTtBQUNuQyxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSUwsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ00sWUFBWUMsYUFBYSxJQUFJUCxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDUSxTQUFTQyxVQUFVLElBQUlULFNBQVMsRUFBRTtBQUV6QyxRQUFNVSxnQkFBZ0IsT0FBT0MsVUFBVTtBQUNyQ0EsVUFBTUMsZUFBZTtBQUNyQlYsZUFBVztBQUFBLE1BQ1RXLE9BQU9UO0FBQUFBLE1BQ1BVLFFBQVFSO0FBQUFBLE1BQ1JTLEtBQUtQO0FBQUFBLElBQ1AsQ0FBQztBQUVESCxpQkFBYSxFQUFFO0FBQ2ZFLGtCQUFjLEVBQUU7QUFDaEJFLGVBQVcsRUFBRTtBQUFBLEVBQ2Y7QUFDQSxTQUNFLHVCQUFDLFNBQ0MsaUNBQUMsVUFBSyxVQUFVQyxlQUNkO0FBQUEsMkJBQUMsU0FDQyxpQ0FBQyxXQUFLO0FBQUE7QUFBQSxNQUVKO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxPQUFPTjtBQUFBQSxVQUNQLFVBQVUsQ0FBQyxFQUFFWSxPQUFPLE1BQU1YLGFBQWFXLE9BQU9DLEtBQUs7QUFBQTtBQUFBLFFBSHJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUd1RDtBQUFBLFNBTHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBQ0EsdUJBQUMsU0FDQyxpQ0FBQyxXQUFLO0FBQUE7QUFBQSxNQUVKO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxPQUFPWDtBQUFBQSxVQUNQLFVBQVUsQ0FBQyxFQUFFVSxPQUFPLE1BQU1ULGNBQWNTLE9BQU9DLEtBQUs7QUFBQTtBQUFBLFFBSHREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUd3RDtBQUFBLFNBTDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBQ0EsdUJBQUMsU0FDQyxpQ0FBQyxXQUFLO0FBQUE7QUFBQSxNQUVKO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxPQUFPVDtBQUFBQSxVQUNQLFVBQVUsQ0FBQyxFQUFFUSxPQUFPLE1BQU1QLFdBQVdPLE9BQU9DLEtBQUs7QUFBQTtBQUFBLFFBSG5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdxRDtBQUFBLFNBTHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsc0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEI7QUFBQSxPQS9COUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdDQSxLQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0NBO0FBRUo7QUFBQ2QsR0F0REtGLFVBQVE7QUFBQWlCLEtBQVJqQjtBQXdETixlQUFlQTtBQUFRLElBQUFpQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJCbG9nRm9ybSIsImNyZWF0ZUJsb2ciLCJfcyIsImJsb2dUaXRsZSIsInNldEJsb2dUaXRsZSIsImJsb2dBdXRob3IiLCJzZXRCbG9nQXV0aG9yIiwiYmxvZ1VybCIsInNldEJsb2dVcmwiLCJjcmVhdGVOZXdCbG9nIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsInRpdGxlIiwiYXV0aG9yIiwidXJsIiwidGFyZ2V0IiwidmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJCbG9nRm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuY29uc3QgQmxvZ0Zvcm0gPSAoeyBjcmVhdGVCbG9nIH0pID0+IHtcbiAgY29uc3QgW2Jsb2dUaXRsZSwgc2V0QmxvZ1RpdGxlXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbYmxvZ0F1dGhvciwgc2V0QmxvZ0F1dGhvcl0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2Jsb2dVcmwsIHNldEJsb2dVcmxdID0gdXNlU3RhdGUoJycpXG5cbiAgY29uc3QgY3JlYXRlTmV3QmxvZyA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcbiAgICBjcmVhdGVCbG9nKHtcbiAgICAgIHRpdGxlOiBibG9nVGl0bGUsXG4gICAgICBhdXRob3I6IGJsb2dBdXRob3IsXG4gICAgICB1cmw6IGJsb2dVcmwsXG4gICAgfSlcblxuICAgIHNldEJsb2dUaXRsZSgnJylcbiAgICBzZXRCbG9nQXV0aG9yKCcnKVxuICAgIHNldEJsb2dVcmwoJycpXG4gIH1cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGZvcm0gb25TdWJtaXQ9e2NyZWF0ZU5ld0Jsb2d9PlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxsYWJlbD5cbiAgICAgICAgICAgIFRpdGxlOlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgdmFsdWU9e2Jsb2dUaXRsZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRCbG9nVGl0bGUodGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGxhYmVsPlxuICAgICAgICAgICAgQXV0aG9yOlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgdmFsdWU9e2Jsb2dBdXRob3J9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0QmxvZ0F1dGhvcih0YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8bGFiZWw+XG4gICAgICAgICAgICBVcmw6XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICB2YWx1ZT17YmxvZ1VybH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRCbG9nVXJsKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIj5jcmVhdGU8L2J1dHRvbj5cbiAgICAgIDwvZm9ybT5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBCbG9nRm9ybVxuIl0sImZpbGUiOiIvaG9tZS9tb2hhbW1hZC9wcm9qZWN0cy9GdWxsU3RhY2tjb3Vyc2UvcGFydDUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQmxvZ0Zvcm0uanN4In0=