import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3eb2504a"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=3eb2504a"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Blog from "/src/components/Blog.jsx";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
import BlogFrom from "/src/components/BlogForm.jsx";
import Toggable from "/src/components/Toggable.jsx";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [notification, setNotification] = useState("");
  const blogFromRed = useRef();
  useEffect(() => {
    blogService.getAll().then((blogs2) => setBlogs(blogs2));
  }, []);
  useEffect(() => {
    const loggedInUser = window.localStorage.getItem("NotesUserDataToken");
    if (loggedInUser) {
      const user2 = JSON.parse(loggedInUser);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({ username, password });
      window.localStorage.setItem("NotesUserDataToken", JSON.stringify(user2));
      setUser(user2);
      setUsername("");
      setPassword("");
      setNotification(`new welcome back ${user2.name}`);
      setTimeout(() => {
        setNotification("");
      }, 5e3);
    } catch (exception) {
      setNotification(exception.message);
      setTimeout(() => {
        setNotification("");
      }, 5e3);
    }
  };
  const handleLogout = () => {
    window.localStorage.clear();
    setUser(null);
    blogService.setToken(null);
  };
  const loginForm = () => /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
    /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("label", { children: [
      "username:",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: username,
          onChange: ({ target }) => setUsername(target.value)
        },
        void 0,
        false,
        {
          fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 79,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 77,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 76,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("label", { children: [
      "password:",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "password",
          value: password,
          onChange: ({ target }) => setPassword(target.value)
        },
        void 0,
        false,
        {
          fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx",
          lineNumber: 90,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 88,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 87,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "Login" }, void 0, false, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 97,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx",
    lineNumber: 75,
    columnNumber: 3
  }, this);
  const createNewBlog = async (newObject) => {
    try {
      blogFromRed.current.toggleVisibility();
      const createdBlog = await blogService.create(newObject);
      setBlogs([...blogs, createdBlog]);
      setNotification(
        `new blog is added ${createdBlog.title} by ${createdBlog.author}`
      );
      setTimeout(() => {
        setNotification("");
      }, 5e3);
    } catch (exception) {
      setNotification(exception.message);
      setTimeout(() => {
        setNotification("");
      }, 5e3);
    }
  };
  const handleDelete = async (blogId) => {
    try {
      setBlogs(blogs.filter((blog) => blog.id !== blogId));
      setNotification("Blog deleted successfully");
      setTimeout(() => {
        setNotification("");
      }, 5e3);
    } catch (exception) {
      setNotification(exception.message);
      setTimeout(() => {
        setNotification("");
      }, 5e3);
    }
  };
  const handleLike = async (blogToLike) => {
    try {
      const updatedBlog = await blogService.updateLike(
        blogToLike.id,
        blogToLike.likes
      );
      setBlogs(blogs.map((b) => b.id === blogToLike.id ? updatedBlog : b));
    } catch (error) {
      console.error("Error updating likes:", error);
    }
  };
  const blogsFrom = () => /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 149,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: [
      user.name,
      " logged in",
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "LogOut" }, void 0, false, {
        fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 152,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 150,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Toggable, { label: "new blog", ref: blogFromRed, children: /* @__PURE__ */ jsxDEV(BlogFrom, { createBlog: createNewBlog }, void 0, false, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 155,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 154,
      columnNumber: 7
    }, this),
    blogs.sort((a, b) => b.likes - a.likes).map(
      (blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, onDelete: handleDelete, onLike: handleLike }, blog.id, false, {
        fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx",
        lineNumber: 160,
        columnNumber: 5
      }, this)
    )
  ] }, void 0, true, {
    fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx",
    lineNumber: 148,
    columnNumber: 3
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    notification && /* @__PURE__ */ jsxDEV("div", { className: "error", children: notification }, void 0, false, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx",
      lineNumber: 166,
      columnNumber: 24
    }, this),
    !user && loginForm(),
    user && blogsFrom()
  ] }, void 0, true, {
    fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx",
    lineNumber: 165,
    columnNumber: 5
  }, this);
};
_s(App, "VOMo3XVFjtWeuEHvuKi5da0uDU8=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkRVOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNEVixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGNBQWM7QUFFckIsTUFBTUMsTUFBTUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJWCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDWSxVQUFVQyxXQUFXLElBQUliLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNjLFVBQVVDLFdBQVcsSUFBSWYsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ2dCLE1BQU1DLE9BQU8sSUFBSWpCLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUNrQixjQUFjQyxlQUFlLElBQUluQixTQUFTLEVBQUU7QUFDbkQsUUFBTW9CLGNBQWNsQixPQUFPO0FBRTNCRCxZQUFVLE1BQU07QUFDZEcsZ0JBQVlpQixPQUFPLEVBQUVDLEtBQUssQ0FBQ1osV0FBVUMsU0FBU0QsTUFBSyxDQUFDO0FBQUEsRUFDdEQsR0FBRyxFQUFFO0FBRUxULFlBQVUsTUFBTTtBQUNkLFVBQU1zQixlQUFlQyxPQUFPQyxhQUFhQyxRQUFRLG9CQUFvQjtBQUNyRSxRQUFJSCxjQUFjO0FBQ2hCLFlBQU1QLFFBQU9XLEtBQUtDLE1BQU1MLFlBQVk7QUFDcENOLGNBQVFELEtBQUk7QUFDWlosa0JBQVl5QixTQUFTYixNQUFLYyxLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU1DLGNBQWMsT0FBT0MsVUFBVTtBQUNuQ0EsVUFBTUMsZUFBZTtBQUNyQixRQUFJO0FBQ0YsWUFBTWpCLFFBQU8sTUFBTVgsYUFBYTZCLE1BQU0sRUFBRXRCLFVBQVVFLFNBQVMsQ0FBQztBQUM1RFUsYUFBT0MsYUFBYVUsUUFBUSxzQkFBc0JSLEtBQUtTLFVBQVVwQixLQUFJLENBQUM7QUFDdEVDLGNBQVFELEtBQUk7QUFDWkgsa0JBQVksRUFBRTtBQUNkRSxrQkFBWSxFQUFFO0FBQ2RJLHNCQUFnQixvQkFBb0JILE1BQUtxQixJQUFJLEVBQUU7QUFDL0NDLGlCQUFXLE1BQU07QUFDZm5CLHdCQUFnQixFQUFFO0FBQUEsTUFDcEIsR0FBRyxHQUFJO0FBQUEsSUFDVCxTQUFTb0IsV0FBVztBQUNsQnBCLHNCQUFnQm9CLFVBQVVDLE9BQU87QUFDakNGLGlCQUFXLE1BQU07QUFDZm5CLHdCQUFnQixFQUFFO0FBQUEsTUFDcEIsR0FBRyxHQUFJO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxRQUFNc0IsZUFBZUEsTUFBTTtBQUN6QmpCLFdBQU9DLGFBQWFpQixNQUFNO0FBQzFCekIsWUFBUSxJQUFJO0FBQ1piLGdCQUFZeUIsU0FBUyxJQUFJO0FBQUEsRUFDM0I7QUFFQSxRQUFNYyxZQUFZQSxNQUNoQix1QkFBQyxVQUFLLFVBQVVaLGFBQ2Q7QUFBQSwyQkFBQyxTQUNDLGlDQUFDLFdBQUs7QUFBQTtBQUFBLE1BRUo7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLE9BQU9uQjtBQUFBQSxVQUNQLFVBQVUsQ0FBQyxFQUFFZ0MsT0FBTyxNQUFNL0IsWUFBWStCLE9BQU9DLEtBQUs7QUFBQTtBQUFBLFFBSHBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdzRDtBQUFBLFNBTHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBRUEsdUJBQUMsU0FDQyxpQ0FBQyxXQUFLO0FBQUE7QUFBQSxNQUVKO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxPQUFPL0I7QUFBQUEsVUFDUCxVQUFVLENBQUMsRUFBRThCLE9BQU8sTUFBTTdCLFlBQVk2QixPQUFPQyxLQUFLO0FBQUE7QUFBQSxRQUhwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHc0Q7QUFBQSxTQUx4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJCO0FBQUEsT0F0QjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1QkE7QUFHRixRQUFNQyxnQkFBZ0IsT0FBT0MsY0FBYztBQUN6QyxRQUFJO0FBQ0YzQixrQkFBWTRCLFFBQVFDLGlCQUFpQjtBQUNyQyxZQUFNQyxjQUFjLE1BQU05QyxZQUFZK0MsT0FBT0osU0FBUztBQUN0RHBDLGVBQVMsQ0FBQyxHQUFHRCxPQUFPd0MsV0FBVyxDQUFDO0FBQ2hDL0I7QUFBQUEsUUFDRSxxQkFBcUIrQixZQUFZRSxLQUFLLE9BQU9GLFlBQVlHLE1BQU07QUFBQSxNQUNqRTtBQUNBZixpQkFBVyxNQUFNO0FBQ2ZuQix3QkFBZ0IsRUFBRTtBQUFBLE1BQ3BCLEdBQUcsR0FBSTtBQUFBLElBQ1QsU0FBU29CLFdBQVc7QUFDbEJwQixzQkFBZ0JvQixVQUFVQyxPQUFPO0FBQ2pDRixpQkFBVyxNQUFNO0FBQ2ZuQix3QkFBZ0IsRUFBRTtBQUFBLE1BQ3BCLEdBQUcsR0FBSTtBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsUUFBTW1DLGVBQWUsT0FBT0MsV0FBVztBQUNyQyxRQUFJO0FBQ0Y1QyxlQUFTRCxNQUFNOEMsT0FBTyxDQUFDQyxTQUFTQSxLQUFLQyxPQUFPSCxNQUFNLENBQUM7QUFDbkRwQyxzQkFBZ0IsMkJBQTJCO0FBQzNDbUIsaUJBQVcsTUFBTTtBQUNmbkIsd0JBQWdCLEVBQUU7QUFBQSxNQUNwQixHQUFHLEdBQUk7QUFBQSxJQUNULFNBQVNvQixXQUFXO0FBQ2xCcEIsc0JBQWdCb0IsVUFBVUMsT0FBTztBQUNqQ0YsaUJBQVcsTUFBTTtBQUNmbkIsd0JBQWdCLEVBQUU7QUFBQSxNQUNwQixHQUFHLEdBQUk7QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUVBLFFBQU13QyxhQUFhLE9BQU9DLGVBQWU7QUFDdkMsUUFBSTtBQUNGLFlBQU1DLGNBQWMsTUFBTXpELFlBQVkwRDtBQUFBQSxRQUNwQ0YsV0FBV0Y7QUFBQUEsUUFDWEUsV0FBV0c7QUFBQUEsTUFDYjtBQUNBcEQsZUFBU0QsTUFBTXNELElBQUksQ0FBQ0MsTUFBT0EsRUFBRVAsT0FBT0UsV0FBV0YsS0FBS0csY0FBY0ksQ0FBRSxDQUFDO0FBQUEsSUFDdkUsU0FBU0MsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHlCQUF5QkEsS0FBSztBQUFBLElBQzlDO0FBQUEsRUFDRjtBQUVBLFFBQU1FLFlBQVlBLE1BQ2hCLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxRQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBQ1QsdUJBQUMsT0FDRXBEO0FBQUFBLFdBQUtxQjtBQUFBQSxNQUFLO0FBQUEsTUFDWCx1QkFBQyxZQUFPLFNBQVNJLGNBQWMsc0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUM7QUFBQSxTQUZ2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLFlBQVMsT0FBTSxZQUFXLEtBQUtyQixhQUM5QixpQ0FBQyxZQUFTLFlBQVkwQixpQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvQyxLQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNDcEMsTUFDRTJELEtBQUssQ0FBQ0MsR0FBR0wsTUFBTUEsRUFBRUYsUUFBUU8sRUFBRVAsS0FBSyxFQUNoQ0M7QUFBQUEsTUFBSSxDQUFDUCxTQUNKLHVCQUFDLFFBQW1CLE1BQVksVUFBVUgsY0FBYyxRQUFRSyxjQUFyREYsS0FBS0MsSUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRTtBQUFBLElBQzVFO0FBQUEsT0FiTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBY0E7QUFFRixTQUNFLHVCQUFDLFNBQ0V4QztBQUFBQSxvQkFBZ0IsdUJBQUMsU0FBSSxXQUFVLFNBQVNBLDBCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFDO0FBQUEsSUFDckQsQ0FBQ0YsUUFBUTJCLFVBQVU7QUFBQSxJQUNuQjNCLFFBQVFvRCxVQUFVO0FBQUEsT0FIckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlBO0FBRUo7QUFBQzNELEdBaEpLRCxLQUFHO0FBQUErRCxLQUFIL0Q7QUFrSk4sZUFBZUE7QUFBRyxJQUFBK0Q7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwiQmxvZyIsImJsb2dTZXJ2aWNlIiwibG9naW5TZXJ2aWNlIiwiQmxvZ0Zyb20iLCJUb2dnYWJsZSIsIkFwcCIsIl9zIiwiYmxvZ3MiLCJzZXRCbG9ncyIsInVzZXJuYW1lIiwic2V0VXNlcm5hbWUiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwidXNlciIsInNldFVzZXIiLCJub3RpZmljYXRpb24iLCJzZXROb3RpZmljYXRpb24iLCJibG9nRnJvbVJlZCIsImdldEFsbCIsInRoZW4iLCJsb2dnZWRJblVzZXIiLCJ3aW5kb3ciLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiSlNPTiIsInBhcnNlIiwic2V0VG9rZW4iLCJ0b2tlbiIsImhhbmRsZUxvZ2luIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImxvZ2luIiwic2V0SXRlbSIsInN0cmluZ2lmeSIsIm5hbWUiLCJzZXRUaW1lb3V0IiwiZXhjZXB0aW9uIiwibWVzc2FnZSIsImhhbmRsZUxvZ291dCIsImNsZWFyIiwibG9naW5Gb3JtIiwidGFyZ2V0IiwidmFsdWUiLCJjcmVhdGVOZXdCbG9nIiwibmV3T2JqZWN0IiwiY3VycmVudCIsInRvZ2dsZVZpc2liaWxpdHkiLCJjcmVhdGVkQmxvZyIsImNyZWF0ZSIsInRpdGxlIiwiYXV0aG9yIiwiaGFuZGxlRGVsZXRlIiwiYmxvZ0lkIiwiZmlsdGVyIiwiYmxvZyIsImlkIiwiaGFuZGxlTGlrZSIsImJsb2dUb0xpa2UiLCJ1cGRhdGVkQmxvZyIsInVwZGF0ZUxpa2UiLCJsaWtlcyIsIm1hcCIsImIiLCJlcnJvciIsImNvbnNvbGUiLCJibG9nc0Zyb20iLCJzb3J0IiwiYSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgQmxvZyBmcm9tICcuL2NvbXBvbmVudHMvQmxvZydcbmltcG9ydCBibG9nU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2Jsb2dzJ1xuaW1wb3J0IGxvZ2luU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2xvZ2luJ1xuaW1wb3J0IEJsb2dGcm9tIGZyb20gJy4vY29tcG9uZW50cy9CbG9nRm9ybSdcbmltcG9ydCBUb2dnYWJsZSBmcm9tICcuL2NvbXBvbmVudHMvVG9nZ2FibGUnXG5cbmNvbnN0IEFwcCA9ICgpID0+IHtcbiAgY29uc3QgW2Jsb2dzLCBzZXRCbG9nc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW25vdGlmaWNhdGlvbiwgc2V0Tm90aWZpY2F0aW9uXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBibG9nRnJvbVJlZCA9IHVzZVJlZigpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBibG9nU2VydmljZS5nZXRBbGwoKS50aGVuKChibG9ncykgPT4gc2V0QmxvZ3MoYmxvZ3MpKVxuICB9LCBbXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGxvZ2dlZEluVXNlciA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnTm90ZXNVc2VyRGF0YVRva2VuJylcbiAgICBpZiAobG9nZ2VkSW5Vc2VyKSB7XG4gICAgICBjb25zdCB1c2VyID0gSlNPTi5wYXJzZShsb2dnZWRJblVzZXIpXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxuICAgIH1cbiAgfSwgW10pXG5cbiAgY29uc3QgaGFuZGxlTG9naW4gPSBhc3luYyAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBsb2dpblNlcnZpY2UubG9naW4oeyB1c2VybmFtZSwgcGFzc3dvcmQgfSlcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnTm90ZXNVc2VyRGF0YVRva2VuJywgSlNPTi5zdHJpbmdpZnkodXNlcikpXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBzZXRVc2VybmFtZSgnJylcbiAgICAgIHNldFBhc3N3b3JkKCcnKVxuICAgICAgc2V0Tm90aWZpY2F0aW9uKGBuZXcgd2VsY29tZSBiYWNrICR7dXNlci5uYW1lfWApXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0Tm90aWZpY2F0aW9uKCcnKVxuICAgICAgfSwgNTAwMClcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIHNldE5vdGlmaWNhdGlvbihleGNlcHRpb24ubWVzc2FnZSlcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBzZXROb3RpZmljYXRpb24oJycpXG4gICAgICB9LCA1MDAwKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUxvZ291dCA9ICgpID0+IHtcbiAgICB3aW5kb3cubG9jYWxTdG9yYWdlLmNsZWFyKClcbiAgICBzZXRVc2VyKG51bGwpXG4gICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4obnVsbClcbiAgfVxuXG4gIGNvbnN0IGxvZ2luRm9ybSA9ICgpID0+IChcbiAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlTG9naW59PlxuICAgICAgPGRpdj5cbiAgICAgICAgPGxhYmVsPlxuICAgICAgICAgIHVzZXJuYW1lOlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgdmFsdWU9e3VzZXJuYW1lfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRVc2VybmFtZSh0YXJnZXQudmFsdWUpfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvbGFiZWw+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdj5cbiAgICAgICAgPGxhYmVsPlxuICAgICAgICAgIHBhc3N3b3JkOlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0UGFzc3dvcmQodGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2xhYmVsPlxuICAgICAgPC9kaXY+XG4gICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIj5Mb2dpbjwvYnV0dG9uPlxuICAgIDwvZm9ybT5cbiAgKVxuXG4gIGNvbnN0IGNyZWF0ZU5ld0Jsb2cgPSBhc3luYyAobmV3T2JqZWN0KSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGJsb2dGcm9tUmVkLmN1cnJlbnQudG9nZ2xlVmlzaWJpbGl0eSgpXG4gICAgICBjb25zdCBjcmVhdGVkQmxvZyA9IGF3YWl0IGJsb2dTZXJ2aWNlLmNyZWF0ZShuZXdPYmplY3QpXG4gICAgICBzZXRCbG9ncyhbLi4uYmxvZ3MsIGNyZWF0ZWRCbG9nXSlcbiAgICAgIHNldE5vdGlmaWNhdGlvbihcbiAgICAgICAgYG5ldyBibG9nIGlzIGFkZGVkICR7Y3JlYXRlZEJsb2cudGl0bGV9IGJ5ICR7Y3JlYXRlZEJsb2cuYXV0aG9yfWAsXG4gICAgICApXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0Tm90aWZpY2F0aW9uKCcnKVxuICAgICAgfSwgNTAwMClcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIHNldE5vdGlmaWNhdGlvbihleGNlcHRpb24ubWVzc2FnZSlcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBzZXROb3RpZmljYXRpb24oJycpXG4gICAgICB9LCA1MDAwKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jIChibG9nSWQpID0+IHtcbiAgICB0cnkge1xuICAgICAgc2V0QmxvZ3MoYmxvZ3MuZmlsdGVyKChibG9nKSA9PiBibG9nLmlkICE9PSBibG9nSWQpKVxuICAgICAgc2V0Tm90aWZpY2F0aW9uKCdCbG9nIGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5JylcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBzZXROb3RpZmljYXRpb24oJycpXG4gICAgICB9LCA1MDAwKVxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgc2V0Tm90aWZpY2F0aW9uKGV4Y2VwdGlvbi5tZXNzYWdlKVxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHNldE5vdGlmaWNhdGlvbignJylcbiAgICAgIH0sIDUwMDApXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlTGlrZSA9IGFzeW5jIChibG9nVG9MaWtlKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHVwZGF0ZWRCbG9nID0gYXdhaXQgYmxvZ1NlcnZpY2UudXBkYXRlTGlrZShcbiAgICAgICAgYmxvZ1RvTGlrZS5pZCxcbiAgICAgICAgYmxvZ1RvTGlrZS5saWtlc1xuICAgICAgKVxuICAgICAgc2V0QmxvZ3MoYmxvZ3MubWFwKChiKSA9PiAoYi5pZCA9PT0gYmxvZ1RvTGlrZS5pZCA/IHVwZGF0ZWRCbG9nIDogYikpKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciB1cGRhdGluZyBsaWtlczonLCBlcnJvcilcbiAgICB9XG4gIH1cblxuICBjb25zdCBibG9nc0Zyb20gPSAoKSA9PiAoXG4gICAgPGRpdj5cbiAgICAgIDxoMj5ibG9nczwvaDI+XG4gICAgICA8cD5cbiAgICAgICAge3VzZXIubmFtZX0gbG9nZ2VkIGluXG4gICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlTG9nb3V0fT5Mb2dPdXQ8L2J1dHRvbj5cbiAgICAgIDwvcD5cbiAgICAgIDxUb2dnYWJsZSBsYWJlbD1cIm5ldyBibG9nXCIgcmVmPXtibG9nRnJvbVJlZH0+XG4gICAgICAgIDxCbG9nRnJvbSBjcmVhdGVCbG9nPXtjcmVhdGVOZXdCbG9nfSAvPlxuICAgICAgPC9Ub2dnYWJsZT5cbiAgICAgIHtibG9nc1xuICAgICAgICAuc29ydCgoYSwgYikgPT4gYi5saWtlcyAtIGEubGlrZXMpXG4gICAgICAgIC5tYXAoKGJsb2cpID0+IChcbiAgICAgICAgICA8QmxvZyBrZXk9e2Jsb2cuaWR9IGJsb2c9e2Jsb2d9IG9uRGVsZXRlPXtoYW5kbGVEZWxldGV9IG9uTGlrZT17aGFuZGxlTGlrZX0vPlxuICAgICAgICApKX1cbiAgICA8L2Rpdj5cbiAgKVxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICB7bm90aWZpY2F0aW9uICYmIDxkaXYgY2xhc3NOYW1lPVwiZXJyb3JcIj57bm90aWZpY2F0aW9ufTwvZGl2Pn1cbiAgICAgIHshdXNlciAmJiBsb2dpbkZvcm0oKX1cbiAgICAgIHt1c2VyICYmIGJsb2dzRnJvbSgpfVxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcFxuIl0sImZpbGUiOiIvaG9tZS9tb2hhbW1hZC9wcm9qZWN0cy9GdWxsU3RhY2tjb3Vyc2UvcGFydDUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL0FwcC5qc3gifQ==