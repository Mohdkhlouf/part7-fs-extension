import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Toggable.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3eb2504a"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Toggable.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=3eb2504a"; const useState = __vite__cjsImport3_react["useState"]; const useImperativeHandle = __vite__cjsImport3_react["useImperativeHandle"];
const Toggable = (props) => {
  _s();
  const [visible, setVislible] = useState(false);
  const hideWhenVisible = { display: visible ? "none" : "" };
  const showWhenVisible = { display: visible ? "" : "none" };
  const toggleVisibility = () => {
    setVislible(!visible);
  };
  useImperativeHandle(props.ref, () => {
    return { toggleVisibility };
  });
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: props.label }, void 0, false, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Toggable.jsx",
      lineNumber: 38,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Toggable.jsx",
      lineNumber: 37,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, children: [
      props.children,
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: "cancel" }, void 0, false, {
        fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Toggable.jsx",
        lineNumber: 43,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Toggable.jsx",
      lineNumber: 41,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Toggable.jsx",
    lineNumber: 36,
    columnNumber: 5
  }, this);
};
_s(Toggable, "vNliJWA1vNcvkMQ3XIVvckxd4h4=");
_c = Toggable;
export default Toggable;
var _c;
$RefreshReg$(_c, "Toggable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Toggable.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Toggable.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JROzs7Ozs7Ozs7Ozs7Ozs7OztBQWxCUixTQUFTQSxVQUFVQywyQkFBMkI7QUFFOUMsTUFBTUMsV0FBV0EsQ0FBQ0MsVUFBVTtBQUFBQyxLQUFBO0FBQzFCLFFBQU0sQ0FBQ0MsU0FBU0MsV0FBVyxJQUFJTixTQUFTLEtBQUs7QUFDN0MsUUFBTU8sa0JBQWtCLEVBQUVDLFNBQVNILFVBQVUsU0FBUyxHQUFHO0FBQ3pELFFBQU1JLGtCQUFrQixFQUFFRCxTQUFTSCxVQUFVLEtBQUssT0FBTztBQUV6RCxRQUFNSyxtQkFBbUJBLE1BQU07QUFDN0JKLGdCQUFZLENBQUNELE9BQU87QUFBQSxFQUN0QjtBQUVBSixzQkFBb0JFLE1BQU1RLEtBQUssTUFBTTtBQUNuQyxXQUFPLEVBQUVELGlCQUFpQjtBQUFBLEVBQzVCLENBQUM7QUFFRCxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxTQUFJLE9BQU9ILGlCQUNWLGlDQUFDLFlBQU8sU0FBU0csa0JBQW1CUCxnQkFBTVMsU0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRCxLQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksT0FBT0gsaUJBQ1ROO0FBQUFBLFlBQU1VO0FBQUFBLE1BQ1AsdUJBQUMsWUFBTyxTQUFTSCxrQkFBa0Isc0JBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUM7QUFBQSxTQUYzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxPQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTQTtBQUVKO0FBQUNOLEdBekJLRixVQUFRO0FBQUFZLEtBQVJaO0FBMkJOLGVBQWVBO0FBQVEsSUFBQVk7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlSW1wZXJhdGl2ZUhhbmRsZSIsIlRvZ2dhYmxlIiwicHJvcHMiLCJfcyIsInZpc2libGUiLCJzZXRWaXNsaWJsZSIsImhpZGVXaGVuVmlzaWJsZSIsImRpc3BsYXkiLCJzaG93V2hlblZpc2libGUiLCJ0b2dnbGVWaXNpYmlsaXR5IiwicmVmIiwibGFiZWwiLCJjaGlsZHJlbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlRvZ2dhYmxlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlSW1wZXJhdGl2ZUhhbmRsZSB9IGZyb20gJ3JlYWN0J1xuXG5jb25zdCBUb2dnYWJsZSA9IChwcm9wcykgPT4ge1xuICBjb25zdCBbdmlzaWJsZSwgc2V0VmlzbGlibGVdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IGhpZGVXaGVuVmlzaWJsZSA9IHsgZGlzcGxheTogdmlzaWJsZSA/ICdub25lJyA6ICcnIH1cbiAgY29uc3Qgc2hvd1doZW5WaXNpYmxlID0geyBkaXNwbGF5OiB2aXNpYmxlID8gJycgOiAnbm9uZScgfVxuXG4gIGNvbnN0IHRvZ2dsZVZpc2liaWxpdHkgPSAoKSA9PiB7XG4gICAgc2V0VmlzbGlibGUoIXZpc2libGUpXG4gIH1cblxuICB1c2VJbXBlcmF0aXZlSGFuZGxlKHByb3BzLnJlZiwgKCkgPT4ge1xuICAgIHJldHVybiB7IHRvZ2dsZVZpc2liaWxpdHkgfVxuICB9KVxuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxkaXYgc3R5bGU9e2hpZGVXaGVuVmlzaWJsZX0+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17dG9nZ2xlVmlzaWJpbGl0eX0+e3Byb3BzLmxhYmVsfTwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgc3R5bGU9e3Nob3dXaGVuVmlzaWJsZX0+XG4gICAgICAgIHtwcm9wcy5jaGlsZHJlbn1cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXt0b2dnbGVWaXNpYmlsaXR5fT5jYW5jZWw8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IFRvZ2dhYmxlXG4iXSwiZmlsZSI6Ii9ob21lL21vaGFtbWFkL3Byb2plY3RzL0Z1bGxTdGFja2NvdXJzZS9wYXJ0NS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Ub2dnYWJsZS5qc3gifQ==