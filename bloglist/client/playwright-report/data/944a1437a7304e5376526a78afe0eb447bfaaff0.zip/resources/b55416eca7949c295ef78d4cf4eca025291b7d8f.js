import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/index.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/index.css"
const __vite__css = ".error {\n    color: red;\n    background: lightgrey;\n    font-size: 20px;\n    border-style: solid;\n    border-radius: 5px;\n    padding: 10px;\n    margin-bottom: 10px;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))