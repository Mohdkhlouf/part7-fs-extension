import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3eb2504a"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Blog.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=3eb2504a"; const useState = __vite__cjsImport3_react["useState"];
import blogService from "/src/services/blogs.js";
const blogStyle = {
  paddingTop: 10,
  paddingLeft: 2,
  border: "solid",
  borderWidth: 1,
  marginBottom: 5
};
const Blog = ({ blog, onDelete, onLike }) => {
  _s();
  const [detailsDisplay, setDetailsDesplay] = useState(false);
  const hidedetails = { display: detailsDisplay ? "none" : "" };
  const viewdetails = { display: detailsDisplay ? "" : "none" };
  const handleRemove = async () => {
    try {
      if (window.confirm(`Remove blog ${blog.title} by ${blog.author}?`)) {
        await blogService.deleteBlog(blog.id);
        onDelete(blog.id);
      }
    } catch (error) {
      console.error("Error deleteing blog", error);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "blog", style: blogStyle, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "blogDetails", style: viewdetails, children: [
      blog.title,
      /* @__PURE__ */ jsxDEV("button", { onClick: () => setDetailsDesplay(!detailsDisplay), children: "Hide" }, void 0, false, {
        fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 51,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: blog.url }, void 0, false, {
        fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 52,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "Likes:",
        blog.likes,
        " ",
        /* @__PURE__ */ jsxDEV("button", { onClick: () => onLike(blog), children: "like" }, void 0, false, {
          fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 54,
          columnNumber: 30
        }, this)
      ] }, void 0, true, {
        fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 53,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: blog.author }, void 0, false, {
        fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 56,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("button", { onClick: handleRemove, children: "Remove" }, void 0, false, {
        fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 58,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 57,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 49,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "blogSummary", style: hidedetails, children: /* @__PURE__ */ jsxDEV("div", { children: [
      blog.title,
      " ",
      blog.author,
      /* @__PURE__ */ jsxDEV("button", { onClick: () => setDetailsDesplay(!detailsDisplay), children: "View" }, void 0, false, {
        fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 64,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 62,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 61,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 48,
    columnNumber: 5
  }, this);
};
_s(Blog, "9pdLgj+sIKSVbxXnrj4wL3w1MoM=");
_c = Blog;
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/mohammad/projects/FullStackcourse/part5/bloglist-frontend/src/components/Blog.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JROzs7Ozs7Ozs7Ozs7Ozs7OztBQS9CUixTQUFTQSxnQkFBZ0I7QUFDekIsT0FBT0MsaUJBQWlCO0FBRXhCLE1BQU1DLFlBQVk7QUFBQSxFQUNoQkMsWUFBWTtBQUFBLEVBQ1pDLGFBQWE7QUFBQSxFQUNiQyxRQUFRO0FBQUEsRUFDUkMsYUFBYTtBQUFBLEVBQ2JDLGNBQWM7QUFDaEI7QUFFQSxNQUFNQyxPQUFPQSxDQUFDLEVBQUVDLE1BQU1DLFVBQVVDLE9BQU8sTUFBTTtBQUFBQyxLQUFBO0FBQzNDLFFBQU0sQ0FBQ0MsZ0JBQWdCQyxpQkFBaUIsSUFBSWQsU0FBUyxLQUFLO0FBQzFELFFBQU1lLGNBQWMsRUFBRUMsU0FBU0gsaUJBQWlCLFNBQVMsR0FBRztBQUM1RCxRQUFNSSxjQUFjLEVBQUVELFNBQVNILGlCQUFpQixLQUFLLE9BQU87QUFFNUQsUUFBTUssZUFBZSxZQUFZO0FBQy9CLFFBQUk7QUFDRixVQUFJQyxPQUFPQyxRQUFRLGVBQWVYLEtBQUtZLEtBQUssT0FBT1osS0FBS2EsTUFBTSxHQUFHLEdBQUc7QUFDbEUsY0FBTXJCLFlBQVlzQixXQUFXZCxLQUFLZSxFQUFFO0FBQ3BDZCxpQkFBU0QsS0FBS2UsRUFBRTtBQUFBLE1BQ2xCO0FBQUEsSUFDRixTQUFTQyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sd0JBQXdCQSxLQUFLO0FBQUEsSUFDN0M7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPdkIsV0FDM0I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsZUFBYyxPQUFPZSxhQUNqQ1I7QUFBQUEsV0FBS1k7QUFBQUEsTUFDTix1QkFBQyxZQUFPLFNBQVMsTUFBTVAsa0JBQWtCLENBQUNELGNBQWMsR0FBRyxvQkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRDtBQUFBLE1BQy9ELHVCQUFDLFNBQUtKLGVBQUtrQixPQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BQ2YsdUJBQUMsU0FBRztBQUFBO0FBQUEsUUFDS2xCLEtBQUttQjtBQUFBQSxRQUFNO0FBQUEsUUFBQyx1QkFBQyxZQUFPLFNBQVMsTUFBTWpCLE9BQU9GLElBQUksR0FBRyxvQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QztBQUFBLFdBRDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBS0EsZUFBS2EsVUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtCO0FBQUEsTUFDbEIsdUJBQUMsU0FDQyxpQ0FBQyxZQUFPLFNBQVNKLGNBQWMsc0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUMsS0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSxlQUFjLE9BQU9ILGFBQ2xDLGlDQUFDLFNBQ0VOO0FBQUFBLFdBQUtZO0FBQUFBLE1BQU07QUFBQSxNQUFFWixLQUFLYTtBQUFBQSxNQUNuQix1QkFBQyxZQUFPLFNBQVMsTUFBTVIsa0JBQWtCLENBQUNELGNBQWMsR0FBRSxvQkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxPQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUJBO0FBRUo7QUFBQ0QsR0F4Q0tKLE1BQUk7QUFBQXFCLEtBQUpyQjtBQTBDTixlQUFlQTtBQUFJLElBQUFxQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJibG9nU2VydmljZSIsImJsb2dTdHlsZSIsInBhZGRpbmdUb3AiLCJwYWRkaW5nTGVmdCIsImJvcmRlciIsImJvcmRlcldpZHRoIiwibWFyZ2luQm90dG9tIiwiQmxvZyIsImJsb2ciLCJvbkRlbGV0ZSIsIm9uTGlrZSIsIl9zIiwiZGV0YWlsc0Rpc3BsYXkiLCJzZXREZXRhaWxzRGVzcGxheSIsImhpZGVkZXRhaWxzIiwiZGlzcGxheSIsInZpZXdkZXRhaWxzIiwiaGFuZGxlUmVtb3ZlIiwid2luZG93IiwiY29uZmlybSIsInRpdGxlIiwiYXV0aG9yIiwiZGVsZXRlQmxvZyIsImlkIiwiZXJyb3IiLCJjb25zb2xlIiwidXJsIiwibGlrZXMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJCbG9nLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IGJsb2dTZXJ2aWNlIGZyb20gJy4uL3NlcnZpY2VzL2Jsb2dzJ1xuXG5jb25zdCBibG9nU3R5bGUgPSB7XG4gIHBhZGRpbmdUb3A6IDEwLFxuICBwYWRkaW5nTGVmdDogMixcbiAgYm9yZGVyOiAnc29saWQnLFxuICBib3JkZXJXaWR0aDogMSxcbiAgbWFyZ2luQm90dG9tOiA1LFxufVxuXG5jb25zdCBCbG9nID0gKHsgYmxvZywgb25EZWxldGUsIG9uTGlrZSB9KSA9PiB7XG4gIGNvbnN0IFtkZXRhaWxzRGlzcGxheSwgc2V0RGV0YWlsc0Rlc3BsYXldID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IGhpZGVkZXRhaWxzID0geyBkaXNwbGF5OiBkZXRhaWxzRGlzcGxheSA/ICdub25lJyA6ICcnIH1cbiAgY29uc3Qgdmlld2RldGFpbHMgPSB7IGRpc3BsYXk6IGRldGFpbHNEaXNwbGF5ID8gJycgOiAnbm9uZScgfVxuXG4gIGNvbnN0IGhhbmRsZVJlbW92ZSA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgaWYgKHdpbmRvdy5jb25maXJtKGBSZW1vdmUgYmxvZyAke2Jsb2cudGl0bGV9IGJ5ICR7YmxvZy5hdXRob3J9P2ApKSB7XG4gICAgICAgIGF3YWl0IGJsb2dTZXJ2aWNlLmRlbGV0ZUJsb2coYmxvZy5pZClcbiAgICAgICAgb25EZWxldGUoYmxvZy5pZClcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZGVsZXRlaW5nIGJsb2cnLCBlcnJvcilcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZ1wiIHN0eWxlPXtibG9nU3R5bGV9PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nRGV0YWlsc1wiIHN0eWxlPXt2aWV3ZGV0YWlsc30+XG4gICAgICAgIHtibG9nLnRpdGxlfVxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldERldGFpbHNEZXNwbGF5KCFkZXRhaWxzRGlzcGxheSl9PkhpZGU8L2J1dHRvbj5cbiAgICAgICAgPGRpdj57YmxvZy51cmx9PC9kaXY+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgTGlrZXM6e2Jsb2cubGlrZXN9IDxidXR0b24gb25DbGljaz17KCkgPT4gb25MaWtlKGJsb2cpfT5saWtlPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2PntibG9nLmF1dGhvcn08L2Rpdj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZVJlbW92ZX0+UmVtb3ZlPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2dTdW1tYXJ5XCIgc3R5bGU9e2hpZGVkZXRhaWxzfT5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICB7YmxvZy50aXRsZX0ge2Jsb2cuYXV0aG9yfVxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0RGV0YWlsc0Rlc3BsYXkoIWRldGFpbHNEaXNwbGF5KX0+XG4gICAgICAgICAgICBWaWV3XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQmxvZ1xuIl0sImZpbGUiOiIvaG9tZS9tb2hhbW1hZC9wcm9qZWN0cy9GdWxsU3RhY2tjb3Vyc2UvcGFydDUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQmxvZy5qc3gifQ==